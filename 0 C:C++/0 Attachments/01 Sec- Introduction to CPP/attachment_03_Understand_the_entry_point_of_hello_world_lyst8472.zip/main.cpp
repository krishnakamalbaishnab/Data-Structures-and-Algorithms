//
//  main.cpp
//  helloworld
//
//  Created by lco on 18/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

//#include <iostream>
//
//int main(int argc, const char * argv[]) {
//    // insert code here...
//    std::cout << "Hello, World!\n";
//    return 0;
//}

#include <cstdio>
using namespace std;

int main(){
    puts("Click on Button");
    puts("create a new player");
    puts("add life to player");
    return 0;
}
